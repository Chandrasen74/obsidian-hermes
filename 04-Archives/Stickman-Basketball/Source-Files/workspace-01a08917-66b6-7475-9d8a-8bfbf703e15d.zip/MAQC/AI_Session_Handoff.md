# MAQC Season 7 — AI Session Handoff
**Updated:** Monday 7 Sep 2026 ~21:30 IST  
**User:** Captain `akulmach74`. Discord from captain. Casual. **UTC first.** Spoilers `||IST||` `||EDT||` `||PDT||`. Rules only from knowledge base. Never invent.

---

## Roster
| Role | Name | Discord | Player ID | Max SP | TZ |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Captain | Akulmach74 | akulmach74 | 64516590 | 18000 | IST |
| P2 | Destroyer | DΣ2TRØYΣR | 67665771 | 15825 | IST |
| P3 | Bowolf | BoWolf | 77849365 | 19181 | EDT |
| P4 | Gunshot | gunshot9099 / Ironside | 56671448 | 21597 | IST |
| P5 | Baby Bird | slimpickles. | 26410318 | 22550 | EDT |

- Role ping: `akulmach maqc team`
- India cutoff ~**11:30 PM IST** (18:00 UTC)
- **Prefer weekends** for the match if possible. **Any day can work.** Still **one exact UTC time**, both type yes, no windows. Lock before Friday 6:00 AM UTC.
- **Registered SP:** 23,000
- Clan: BULBA. Clan leader Sticky (`st¢ky¢kyBULBA`) — advice: ping mods in the battle post early if opp is rigid; you did what you could Week 2.
- Gunshot 31 Aug APX pub screenshot: **ignore** (random, not MAQC).

---

## Week 1 — #640 Bracket 8
vs @ita_lev06 · Biogear Lab · **L 1–2** (4v5, late join)

## Week 2 — #671 Bracket 8 · **DOUBLE AUTO-LOSS**
vs @shegotyou88 / @TOXIC&TASTY · Skyship 11  
Mod night: no agreed time, range vs lower end, no valid result. Channel locked. Rulings final.  
**Lesson:** **one UTC clock, both type yes. No ranges.**

## Week 3 — closed (Paradise Plaza · #668 vs @mrjama0586)
- Mod time Sat 13:30 UTC. Result: **not recorded here** — don’t invent. Add when captain confirms.

## Week 4 — LIVE
- **Match #668** Bracket 8
- **Us:** @akulmach74 · 23,000
- **Opp:** **@mrjama0586** · **22,364**
- **IDs:** `80180944, 84061161, 14149516, 36852950, 11632048`
- **Map:** Paradise Plaza · CPC · Bo3 · Equalize
- **MOD TIME (final if nothing else agreed):** Saturday 5 Sep 2026 **13:30 UTC** `<t:1788615000:F>` ||IST: 7:00 PM|| ||EDT: 9:30 AM|| ||Colombia: 8:30 AM||. Can still play another time if **both yes**. Else this is the time. Code in post, ping opp, **10 min**, then bots + **Equalize**. Results before Sun 6 Sep 6:00 AM UTC. Tag **Pending Verification**.
- **Captain already sent in battle post (31 Aug):** one exact time not a window; prefer weekend any day works; Saturday **3:00 / → 4:00 (best) / 5:00 PM UTC** as `<t:1788620400:F>` `<t:1788624000:F>` `<t:1788627600:F>` with `||UTC||` spoilers; send a time not a window; lock before `<t:1788501600:F>`.
- **Captain hangar read (31 Aug):** matchmaking **pretty balanced**. Strat **not locked** — talk with Gunshot, run practice, then confirm.
- Hangar screenshots: **not in workspace this turn** — re-drop to log mech-by-mech.
- **Next combined team ping:** times already sent + hangars + strat once confirmed. Don’t re-ping opponent unless they reply.
- **Posts:** #s07-battle-posts-week-03 (channel id 1543728915950997565)
- **MM:** #s07-mm-list
- **Week:** now → **Sun 6 Sep 2026, 6:00 AM UTC**
- **Ticket / unresponsive / can’t-agree:** **before Fri 4 Sep 2026, 6:00 AM UTC**. After that = too late, **both loss** if you wait until Saturday.
- Field: **1,327 teams**
- **New scheduling (Week 3):**
  1. Both leaders **explicitly agree one specific time** in the forum post
  2. Reschedule: notify **≥6 hours** before original time
  3. Ghost / can’t agree → **ticket** in #maqc-support-leaders **before Fri 6:00 AM UTC**
  4. **No ranges.** Don’t pick one end of a window without a **yes**.

## Practice
Daily ~1h. Prefer **15:00 or 16:00 UTC** (single times). Gunshot 18:00 UTC = IST cutoff.

## Channels
- Week 4 posts: https://discord.com/channels/542314937624690688/1545978594914992168
- Week 3 posts: https://discord.com/channels/542314937624690688/1543728915950997565
- Tickets: https://discord.com/channels/542314937624690688/1533319063185522800
- Site: https://maqc.mecharenadev.com/
